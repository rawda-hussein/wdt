//ssrc/pages/Booking.js

import React, { useState } from "react";
import "../styles/global.css"; 
import services from "../data/ServicesData";

const Booking = () => {
  const [selectedService, setSelectedService] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Booking confirmed for ${selectedService} on ${date} at ${time}`);
  };

  return (
    <div className="booking-page">
      <div className="booking-container">
        <h1 className="booking-title">Book a Service</h1>

        
        <form onSubmit={handleSubmit} className="booking-form">
          <div>
            <label>Select Service:</label>
            <select
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
              required
            >
              <option value="">-- Choose a Service --</option>
              {services.map((service) => (
                <option key={service.id} value={service.title}>
                  {service.title} ({service.price})
                </option>
              ))}
            </select>
          </div>

          
          <div>
            <label>Select Date:</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </div>

          
          <div>
            <label>Select Time:</label>
            <input
              type="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              required
            />
          </div>

          
          <button type="submit" className="booking-button">
            Confirm Booking
          </button>
        </form>
      </div>
    </div>
  );
};

export default Booking;
