//ssrc/pages/Home.js

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import heroImage1 from "../assets/images/last.jpg";
import heroImage2 from "../assets/images/last2.jpg";
import heroImage3 from "../assets/images/last3.jpg";
import heroImage4 from "../assets/images/last4.jpg"; 

import horseVideo from "../assets/videos/its.mp4";
import "../styles/global.css"; 

const images = [heroImage1, heroImage2, heroImage3, heroImage4]; 

const Home = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 2000);

    return () => clearInterval(interval); 
  }, [images.length]); 

  return (
    <div className="home-container">
      <div className="hero-section">
        <img src={images[currentImageIndex]} alt="Horse Farm" className="hero-image fade-in" />
        <div className="hero-content">
          <h1 className="hero-title">Welcome to Horse Farm</h1>
          <p className="hero-text">Discover the beauty of horses and equestrian excellence.</p>
          <Link to="/horses" className="explore-button">
            Explore Our Horses
          </Link>
        </div>
      </div>

      <section className="about-section">
        <div className="text-content">
          <h2 className="section-title">About Our Farm</h2>
          <p className="section-text">
            At our farm, we offer a variety of services including premium horse riding experiences, training for both adults and children, and horse rentals. Our horses are well-trained, well-fed, and receive regular care to ensure they are in optimal condition. Visitors will have the opportunity to enjoy a fantastic experience, surrounded by the beauty and grace of our horses.
          </p>
        </div>
      </section>

      
      <section className="farm-introduction-section">
        <div className="farm-video-container">
          <video autoPlay loop muted>
            <source src={horseVideo} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        </div>
        <div className="farm-description-container">
          <h3 className="farm-title">Our Farm Services</h3>
          <p className="farm-description">
            We specialize in providing high-quality horse training and rentals. Our experienced trainers ensure that every horse is trained to perfection. Children and adults alike can enjoy learning to ride in a safe and supportive environment. Our horses are well cared for, fed nutritious meals, and receive regular grooming to keep them in top shape. Visitors will have a memorable and enjoyable experience at our farm.
          </p>
        </div>
      </section>

      <section className="join-section">
        <h2 className="section-title">Join Us Today</h2>
        <div className="buttons-container">
          <Link to="/auth" className="signup-button">
            Sign Up
          </Link>
          <Link to="/auth" className="login-button">
            Login
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
