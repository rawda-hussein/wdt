//ssrc/pages/Store.js

import React, { useState } from "react";
import "../styles/global.css";

const products = [
  {
    id: 1,
    name: "Horse Saddle",
    category: "Equipment",
    price: "$200",
    image: "/images/saddle.jpg",
  },
  {
    id: 2,
    name: "Riding Helmet",
    category: "Equipment",
    price: "$80",
    image: "/images/helmet.jpg",
  },
  {
    id: 3,
    name: "Horse Blanket",
    category: "Accessories",
    price: "$50",
    image: "/images/blanket.jpg",
  },
  {
    id: 4,
    name: "Grooming Kit",
    category: "Accessories",
    price: "$30",
    image: "/images/grooming-kit.jpg",
  },
];

const Store = () => {
  const [cart, setCart] = useState([]);
  const [filter, setFilter] = useState("All");

  const addToCart = (product) => {
    setCart([...cart, product]);
    alert(`${product.name} added to cart!`);
  };

  const filteredProducts =
    filter === "All" ? products : products.filter((p) => p.category === filter);

  return (
    <div className="store-container">
      <h1 className="store-title">Horse Accessories Store</h1>
      <div className="filter-buttons">
        <button onClick={() => setFilter("All")} className={filter === "All" ? "active" : ""}>
          All
        </button>
        <button onClick={() => setFilter("Equipment")} className={filter === "Equipment" ? "active" : ""}>
          Equipment
        </button>
        <button onClick={() => setFilter("Accessories")} className={filter === "Accessories" ? "active" : ""}>
          Accessories
        </button>
      </div>
      <div className="product-grid">
        {filteredProducts.map((product) => (
          <div key={product.id} className="product-card">
            <img src={product.image} alt={product.name} className="product-image" />
            <h2 className="product-name">{product.name}</h2>
            <p className="product-price">{product.price}</p>
            <button onClick={() => addToCart(product)} className="add-to-cart">Add to Cart</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Store;
