//ssrc/pages/GiftCards.js

import React, { useState } from "react";
import "../styles/giftcard.css"; 

const GiftCard = () => {
  const [formData, setFormData] = useState({
    amount: "50",
    recipientEmail: "",
    message: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Gift Card of $${formData.amount} sent to ${formData.recipientEmail}`);
  };

  return (
    <div className="gift-card-container">
      <div className="gift-card-box">
        <h1 className="gift-card-title">Send a Gift Card</h1>
        <form onSubmit={handleSubmit} className="gift-card-form">
          <label>
            <span>Select Amount:</span>
            <select name="amount" value={formData.amount} onChange={handleChange}>
              <option value="50">$50</option>
              <option value="100">$100</option>
              <option value="150">$150</option>
              <option value="200">$200</option>
            </select>
          </label>

          <label>
            <span>Recipient's Email:</span>
            <input
              type="email"
              name="recipientEmail"
              value={formData.recipientEmail}
              onChange={handleChange}
              required
            />
          </label>

          <label>
            <span>Personal Message (optional):</span>
            <textarea
              name="message"
              value={formData.message}
              onChange={handleChange}
              rows="3"
              placeholder="Write a message for your friend..."
            />
          </label>

          <button type="submit" className="gift-card-button">
            Send Gift Card
          </button>
        </form>
      </div>
    </div>
  );
};

export default GiftCard;
