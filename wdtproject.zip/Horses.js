// //ssrc/pages/Horses.js
import React, { useState } from "react";
import "../styles/global.css";
import horses from "../data/Horsess";

const Horses = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSale, setFilterSale] = useState(false);

  const filteredHorses = horses.filter((horse) => {
    return (
      horse.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (!filterSale || horse.forSale)
    );
  });

  return (
    <div className="horses-container">
      <div className="horses-content">
        <h1 className="horses-title">Our Horses</h1>

        <div className="horses-filters">
          <input
            type="text"
            placeholder="Search for a horse..."
            className="search-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <label className="filter-label">
            <input
              type="checkbox"
              checked={filterSale}
              onChange={() => setFilterSale(!filterSale)}
            />
            Show only horses for sale
          </label>
        </div>

        <div className="horses-grid">
          {filteredHorses.length > 0 ? (
            filteredHorses.map((horse) => (
              <div key={horse.id} className="horse-card">
                <div className="horse-image-container">
                  <img src={horse.image} alt={horse.name} className="horse-image" />
                  <div className="horse-details">
                    <h2 className="horse-name">{horse.name}</h2>
                    <p className="horse-info">Breed: {horse.breed}</p>
                    <p className="horse-info">Age: {horse.age} years</p>
                    {horse.forSale ? (
                      <p className="horse-price available">Price: ${horse.price}</p>
                    ) : (
                      <p className="horse-price not-available">Not for Sale</p>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="no-horses">No horses found!</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Horses;

