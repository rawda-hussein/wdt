//ssrc/pages/Contact.js
import React, { useState } from "react";
import "../styles/global.css"; 

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Message sent! We will contact you soon.`);
    setFormData({ name: "", email: "", message: "" }); 
  };

  return (
    <div className="contact-page">
      <div className="contact-container">
        <h1 className="contact-title">Contact Us</h1>
        <p className="contact-description">
          Have a question? Reach out to us, and we’ll be happy to assist you!
        </p>

        {/* قسم معلومات التواصل */}
        <div className="contact-grid">
          <div className="contact-card">
            <h2>Our Contact Details</h2>
            <p><strong>Phone:</strong> +123 456 7890</p>
            <p><strong>Email:</strong> info@horsesfarm.com</p>
            <p><strong>Address:</strong> 123 Horse Road, Country</p>
            <p><strong>Social Media:</strong></p>
            <div className="contact-social">
              <a href="#">📘</a>
              <a href="#">📷</a>
              <a href="#">🐦</a>
            </div>
          </div>

          {/* خريطة جوجل */}
          <div className="contact-card contact-map">
            <h2>Find Us</h2>
            <iframe
              title="Google Map"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.8354345093704!2d144.95373631590464!3d-37.816279742021024!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0xf5774babc81f8e1b!2sFederation%20Square!5e0!3m2!1sen!2sus!4v1618353538361!5m2!1sen!2sus"
              allowFullScreen
            ></iframe>
          </div>
        </div>

        
        <div className="contact-form-container">
          <h2>Send Us a Message</h2>
          <form onSubmit={handleSubmit} className="contact-form">
            <input
              type="text"
              name="name"
              placeholder="Your Name"
              value={formData.name}
              onChange={handleChange}
              required
            />
            <input
              type="email"
              name="email"
              placeholder="Your Email"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <textarea
              name="message"
              placeholder="Your Message"
              value={formData.message}
              onChange={handleChange}
              required
            ></textarea>
            <button type="submit" className="contact-button">
              Send Message
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contact;
