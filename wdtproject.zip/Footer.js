
// src/components/Footer.js
import React from "react";
import { Link } from "react-router-dom";
import "../styles/footer.css"; // تأكد من استيراد ملف CSS

const Footer = () => {
  return (
    <footer className="footer">
      <p>© 2025 Horse Farm. All rights reserved.</p>
      <div className="footer-links">
        <Link to="/contact">Contact Us</Link>
        <a href="https://www.instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a>
        <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a>
      </div>
    </footer>
  );
};

export default Footer;
