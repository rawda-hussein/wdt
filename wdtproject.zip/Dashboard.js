//ssrc/pages/Dashboard.js

import React, { useState } from "react";
import "../styles/global.css"; 

const Dashboard = () => {
  const [userType, setUserType] = useState("user"); 

  return (
    <div className="dashboard-container">
      <div className="dashboard-content">
        <h1 className="dashboard-title">Dashboard</h1>

        
        <div className="user-type-toggle">
          <button
            onClick={() => setUserType("user")}
            className={`toggle-button ${userType === "user" ? "active" : ""}`}
          >
            User View
          </button>
          <button
            onClick={() => setUserType("admin")}
            className={`toggle-button ${userType === "admin" ? "active" : ""}`}
          >
            Admin View
          </button>
        </div>

        
        {userType === "user" && (
          <div className="dashboard-box">
            <h2 className="dashboard-subtitle">Welcome, Rider! 🏇</h2>
            <ul className="dashboard-list">
              <li className="dashboard-item">Book a Horse Ride</li>
              <li className="dashboard-item">View My Bookings</li>
              <li className="dashboard-item">Explore Horses</li>
            </ul>
          </div>
        )}

        
        {userType === "admin" && (
          <div className="dashboard-box">
            <h2 className="dashboard-subtitle">Admin Panel 🛠️</h2>
            <ul className="dashboard-list">
              <li className="dashboard-item">Manage Horses</li>
              <li className="dashboard-item">Manage Bookings</li>
              <li className="dashboard-item">Manage Services</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
