//src/components/Navbar.js
import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../styles/navbar.css"; // تأكد أنك مستورد ملف الـ CSS هنا

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="logo">
          Horse Farm
        </Link>

        <button className="menu-button" onClick={() => setIsOpen(!isOpen)}>
          ☰
        </button>

        <div className={`nav-links ${isOpen ? "open" : ""}`}>
          <Link to="/">Home</Link>
          <Link to="/about">About Us</Link>
          <Link to="/horses">Horses</Link>
          <Link to="/services">Services</Link>
          <Link to="/booking">Booking</Link>
          <Link to="/contact">Contact</Link>
          <Link to="/store">Store</Link>
          <Link to="/gift-cards">Gift Cards</Link>
          <Link to="/auth" className="navbar-button">
            Login
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
