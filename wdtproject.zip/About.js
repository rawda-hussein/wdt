// //ssrc/pages/About.js

import React from "react";
import "../styles/global.css"; 

const About = () => {
  return (
    <div className="about-container">
      
      <div className="header-section">
        <video autoPlay muted loop className="header-video">
          <source src={require('../assets/videos/horse-video.mp4')} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
        <div className="header-overlay">
          <h1 className="header-title">About Our Farm</h1>
          <p className="header-text">A legacy of excellence in horse training and breeding.</p>
        </div>
      </div>

      
      <section className="history-section">
        <h2 className="section-title">Our History</h2>
        <p className="section-text">
          Established over 20 years ago, our horse farm has been a symbol of excellence in equestrian training, 
          horse breeding, and top-tier services. We pride ourselves on providing the best facilities for both 
          riders and horses.
        </p>
      </section>

     
      <section className="services-section">
        <h2 className="section-title">Our Services</h2>
        <div className="services-grid">
          <div className="service-card">
            <h3 className="service-title">Horse Training</h3>
            <p className="service-text">Professional training for riders of all levels.</p>
          </div>
          <div className="service-card">
            <h3 className="service-title">Horse Breeding</h3>
            <p className="service-text">High-quality horse breeding with premium bloodlines.</p>
          </div>
          <div className="service-card">
            <h3 className="service-title">Riding Sessions</h3>
            <p className="service-text">Book riding lessons with our expert instructors.</p>
          </div>

          
          <div className="service-card">
            <h3 className="service-title">Horse Care</h3>
            <p className="service-text">Comprehensive care and grooming services for your horse.</p>
          </div>

          <div className="service-card">
            <h3 className="service-title">Equestrian Events</h3>
            <p className="service-text">Host and participate in exciting equestrian events.</p>
          </div>

          <div className="service-card">
            <h3 className="service-title">Horse Boarding</h3>
            <p className="service-text">Safe and comfortable boarding facilities for your horse.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
