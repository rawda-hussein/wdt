//ssrc/pages/Services.js

import React from "react";
import "../styles/global.css"; 
import services from "../data/ServicesData";
import { Link } from "react-router-dom";

const Services = () => {
  return (
    <div className="services-page">
      <div className="services-container">
        <h1 className="services-title">Our Services</h1>
        <p className="services-description">
          Explore our professional equestrian services, from training to horse rentals.
        </p>

        
        <div className="services-grid">
          {services.map((service) => (
            <div key={service.id} className="service-card">
              <img src={service.image} alt={service.title} />
              <h2>{service.title}</h2>
              <p>{service.description}</p>
              <p className="service-price">{service.price}</p>
              <Link to="/booking" className="service-button">
                Book Now
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Services;
